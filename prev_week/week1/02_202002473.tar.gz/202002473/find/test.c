#include <stdio.h>

void main(){

	printf("Hello I'm test.c"\n);
}
